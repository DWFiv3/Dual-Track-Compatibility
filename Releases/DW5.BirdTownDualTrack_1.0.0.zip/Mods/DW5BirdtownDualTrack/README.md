# DWFiv3's Birdtown Dual Tracks Compatibility Mod

Mod to make my Dual Tracks mod compatable with Birdtown

# Change Log



### Version 1.0.0
- Moved Gold mine entry to outer span and moved nodes to suite
- Added additional node and adjusted X to move it away from the node used 3 times
- Squished the X to fix up beside the new barn
- Joined barn track to the inner line and added another join between tracks